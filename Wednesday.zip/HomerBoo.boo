import Microsoft.VisualBasic
import System
import System.Windows.Forms as WinForms

import Boo.Lang.Interpreter
import WindowEyes as WE

class HomerBoo:
interpreter as InteractiveInterpreter

def constructor():
interpreter = InteractiveInterpreter(RememberLastValue:true)
end

def Eval(sCode as string, v1 as object, v2 as object, v3 as object, v4 as object) as object:
interpreter.SetValue("v1", v1)
interpreter.SetValue("v2", v2)
interpreter.SetValue("v3", v3)
interpreter.SetValue("v4", v4)
interpreter.Eval(sCode)
return interpreter.LastValue
end # Eval method
end # HomerBoo class

# Main routine
oWE as WE.Application = Interaction.CreateObject("WindowEyes.Application", "")
iID = System.Diagnostics.Process.GetCurrentProcess().Id
oWE.ClientIdentify(iID)
oClient as WE.ClientInformation = oWE.ClientInformation
oClient.ScriptName = "HomerBoo"
oClient.ScriptVersion = "1.0"
oClient.ScriptDescription = "Access the Eval function of Boo at runtime."
oClient.ScriptHelp = """
HomerBoo is a shared Object that provides access to an evaluate function of the Boo language at runtime.
Pass five parameters:  the string of code to be executed and four parameters that may be referenced within it.
"""

oHomerBoo = HomerBoo()
oWE.SharedObjects.Register("org.NonvisualDevelopment.HomerBoo", oHomerBoo)
WinForms.Application.Run()
