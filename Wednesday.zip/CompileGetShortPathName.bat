@echo off
cls
booc.exe -nologo -v -wsa GetShortPathName.boo
