@echo off
cls
booc.exe -nologo -v -wsa URLDownloadToFile.boo
