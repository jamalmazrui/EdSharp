Option Explicit

Dim iResult
Dim oBoo, oSystem, oCodeFile
Dim sResult, sCodeFile, sCode, sTitle, sMessage
Dim v1, v2, v3, v4

' Create the shared object for evaluating Boo code
Set oBoo = SharedObjects("org.NonvisualDevelopment.HomerBoo")

' Set the URL and file variables to be passed to the code for a download task
v1 = "http://GWMicro.com"
v2 = ClientInformation.ScriptPath & "\temp.htm"

' These parameters are not used for this task
' v3 = ""
' v4 = ""

Set oSystem = CreateObject("Scripting.FileSystemObject")
sCodeFile = ClientInformation.ScriptPath & "\URLDownloadToFile.boo"
Set oCodeFile = oSystem.OpenTextFile(sCodeFile)
sCode = oCodeFile.ReadAll
oCodeFile.Close

' MsgBox sCode, 0, "Code"
' Delete the target file if it exists
If oSystem.FileExists(v2) Then oSystem.DeleteFile(v2)

' Evaluate the code
Clipboard.Text = sCode
iResult = oBoo.Eval(sCode, v1, v2, v3, v4)
MsgBox iResult, 0, "Results"
sResult = "Download failed"
If oSystem.FileExists(v2) Then sResult = "Download succeeded"
MsgBox "", 0, sResult

' Another download method using classes of the .NET framework
' Define the multi-line block of code
sCode = "import Microsoft.VisualBasic.Devices from Microsoft.VisualBasic.dll" & vbCrLf
sCode = sCode & "oNetwork = Network()" & vbCrLf
sCode = sCode & "oNetwork.DownloadFile(v1, v2)"

' Delete the target file if it exists
If oSystem.FileExists(v2) Then oSystem.DeleteFile(v2)

' Evaluate the code
oBoo.Eval sCode, v1, v2, v3, v4

' Determine if the target file exists and display the result
sResult = "Download failed"
If oSystem.FileExists(v2) Then sResult = "Download succeeded"
MsgBox "", 0, sResult

' Clean up
Set oCodeFile = Nothing
Set oSystem = Nothing
Set oBoo = Nothing
StopScript

