@echo off
cls
if exist HomerBoo.exe del HomerBoo.exe
rem Uncomment following line for console-mode executable, easier to debug
Booc.exe -nologo -v -wsa -r:WindowEyes.dll -r:Microsoft.VisualBasic.dll HomerBoo.Boo
rem Uncomment following line for GUI executable
rem Booc.exe -nologo -v -t:winexe -wsa -r:WindowEyes.dll -r:Microsoft.VisualBasic.dll HomerBoo.Boo
rem Uncomment following line to merge DLLs with executable
rem ilmerge.exe -out:HomerBoo.exe HomerBoo.exe windoweyes.dll scripting.dll