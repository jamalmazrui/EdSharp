import System
import System.Runtime.InteropServices

# Define Boo wrapper for Win32 function
[DllImport("URLMon.dll")]
def URLDownloadToFile(i1 as int, sUrl as string, sFile as string, i2 as int, i3 as int) as int: end

# v1 = "http://gwmicro.com"
# v2 = "c:\\wescript\\temp.htm"
# Call function and return result as last value
iResult = URLDownloadToFile(0, v1, v2, 0, 0)
iResult
