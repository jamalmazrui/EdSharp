import Microsoft.VisualBasic
import System
import System.Diagnostics
import System.IO
import System.Windows.Forms as WinForms

import Boo.Lang.Compiler.Steps
import Boo.Lang.Interpreter

interpreter = InteractiveInterpreter(RememberLastValue:true)
sFile = 'URLDownloadToFile.boo'
sCode = File.ReadAllText(sFile)
interpreter.Eval(sCode)
