import System.Runtime.InteropServices

[DllImport("user32.dll")]
def MessageBeep(n as uint) as int:
	pass

MessageBeep(0)
