# import Microsoft.VisualBasic
import System
# import System.Diagnostics
import System.IO
# import System.Windows.Forms as WinForms

# import Boo.Lang.Compiler.Steps
import Boo.Lang.Interpreter

class HomerBoo(InteractiveInterpreter):

def Eval(sCode as string, v1 as object, v2 as object, v3 as object, v4 as object):
self.RememberLastValue = true
self.SetValue('v1', v1)
self.SetValue('v2', v2)
self.SetValue('v3', v3)
self.SetValue('v4', v4)
super.Eval(sCode)
return self.LastValue
end # Evaluator method
end # Evaluator class

interpreter = HomerBoo()
sFile = 'URLDownloadToFile.boo'
sCode = File.ReadAllText(sFile)
interpreter.Eval(sCode)
