@echo off
cls
booc.exe -nologo -wsa -v TestInterpreter.boo
