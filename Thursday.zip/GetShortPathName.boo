import System
import System.Text
import System.Runtime.InteropServices

# Define Boo wrapper for Win32 function
[DllImport("kernel32.dll")]
def GetShortPathName(sLongPath as String, sShortPath as StringBuilder, iLength as int):

	pass

# Call function and return result as last value
sShortPath = StringBuilder(260)
v1 = """C:\Documents and Settings\jamal.mazrui\Application Data\GW Micro\Window-Eyes\users\default\Window-Eyes Scripting Manual.chm"""
GetShortPathName(v1, sShortPath, 260)
sResult = sShortPath.ToString().Trim()
print(sResult)
