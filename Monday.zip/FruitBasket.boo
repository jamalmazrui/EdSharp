/*
Fruit Basket program in Boo
Public domain by Jamal Mazrui
March 22, 2010
*/

# Import namespace
import System.Windows.Forms

[STAThread]
# Create controls
tlp = TableLayoutPanel(ColumnCount : 3, RowCount : 2)
lblFruit = Label(Text : '&Fruit:')
txtFruit = TextBox()
btnAdd = Button(Text : '&Add')
lblBasket = Label(Text : '&Basket:')
lstBasket = ListBox()
btnDelete = Button(Text : '&Delete')
tlp.Controls.AddRange((lblFruit, txtFruit, btnAdd, lblBasket, lstBasket, btnDelete))

# Define Add event handler
btnAdd.Click += do:
sFruit = txtFruit.Text
# return MessageBox.Show('No fruit to add!', 'Alert') if sFruit.Length == 0
return MessageBox.Show('No fruit to add!', 'Alert') if not sFruit
lstBasket.Items.Add(sFruit)
txtFruit.Clear()
lstBasket.SelectedIndex = lstBasket.Items.Count - 1
end # do

# Define Delete event handler
btnDelete.Click += do:
iIndex = lstBasket.SelectedIndex
return MessageBox.Show('No fruit to delete.', 'Alert') if iIndex == -1 
lstBasket.Items.RemoveAt(iIndex)
iIndex -- if iIndex == lstBasket.Items.Count
lstBasket.SelectedIndex = iIndex if iIndex >= 0
end # do

# Finalize dialog
dlg = Form(Text : 'Fruit Basket', AcceptButton : btnAdd, StartPosition : FormStartPosition.CenterScreen, AutoSize : true, AutoSizeMode : AutoSizeMode.GrowAndShrink)
dlg.Controls.Add(tlp)
dlg.ShowDialog()
