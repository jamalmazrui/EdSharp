import System
import System.Windows.Forms

# [Module]
class App():
[STAThread]
static def Main():
sText = "testing 1 2 3"
Clipboard.SetText(sText)
end
end

# [STAThread]
App.Main()
