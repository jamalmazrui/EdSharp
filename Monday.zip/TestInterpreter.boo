import System
import System.IO
# import System.Collections

import Boo.Lang
import Boo.Lang.Compiler
# import Boo.Lang.Compiler.Ast
# import Boo.Lang.Compiler.IO
import Boo.Lang.Interpreter
import Boo.Lang.Parser

class HomerBoo(InteractiveInterpreter):

def constructor(parser as ICompilerStep):
super(parser)
# InitializeStandardReferences()
end # constructor

public def EvaluateFile(sFile as string, v1 as object, v2 as object, v3 as object, v4 as object) as object:
sCode = File.ReadAllText(sFile)
print sCode
return Evaluate(sCode, v1, v2, v3, v4)
end # EvaluateFile method

public def Evaluate(sCode as string, v1 as object, v2 as object, v3 as object, v4 as object) as object:
self.RememberLastValue = true
self.SetValue('v1', v1)
self.SetValue('v2', v2)
self.SetValue('v3', v3)
self.SetValue('v4', v4)
self.Eval(sCode)
return self.LastValue
end # Evaluate method
end # HomerBoo class

interpreter = HomerBoo(Boo.Lang.Parser.WSABooParsingStep())  
sFile = 'wsa_URLDownloadToFile.boo'
sFile = 'wsa_GetShortPathName.boo'
sFile = 'wsa_FruitBasket.boo'
sCode = File.ReadAllText(sFile)
# v1 = 'http://boo.codehaus.org'
v2 = 'boo.htm'
v1 = """C:\Documents and Settings\jamal.mazrui\Application Data\GW Micro\Window-Eyes\users\default\Window-Eyes Scripting Manual.chm"""
v3 as object
v4 as object
# result = interpreter.Evaluate(sCode, v1, v2, v3, v4)
result = interpreter.EvaluateFile(sFile, v1, v2, v3, v4)
print result
