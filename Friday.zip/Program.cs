﻿using Renovation;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace TextGrabDemo_CSharp
{
public class Win32 {
[DllImport("user32.dll")]
public static extern int AttachThreadInput(int iThread1, int iThread2, int iAttach);

[DllImport("user32.dll")]
public static extern IntPtr GetActiveWindow();

[DllImport("user32.dll")]
public static extern int BringWindowToTop(IntPtr h);

[DllImport("user32.dll")]
public static extern int ShowWindow(IntPtr h, int iState);

[DllImport("kernel32.dll")]
public static extern int GetCurrentThreadId();

[DllImport("user32.dll")]
public static extern int GetWindowThreadProcessId(IntPtr h, int iProcess);

public static bool ForceWindow(IntPtr h) {
int iForegroundThread = GetWindowThreadProcessId(GetForegroundWindow(), 0);
int iAppThread = GetCurrentThreadId();
if (iForegroundThread == iAppThread) {
BringWindowToTop(h);
ShowWindow(h,3);
}
else {
AttachThreadInput(iForegroundThread, iAppThread, 1);
BringWindowToTop(h);
ShowWindow(h,3);
AttachThreadInput(iForegroundThread, iAppThread, 0);
}

return GetActiveWindow() == h;
} // ForceWindow method

[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
public static extern int GetShortPathName(string path, StringBuilder shortPath, int shortPathLength);
public static string GetShortPath(string sLongPath) {
StringBuilder sbShortPath = new StringBuilder(260);
GetShortPathName(sLongPath, sbShortPath, sbShortPath.Capacity);
string sReturn = sbShortPath.ToString().Trim();
if (sReturn.Length == 0) sReturn = Path.Combine(GetShortPath(Path.GetDirectoryName(sLongPath)), Path.GetFileName(sLongPath));
return sReturn;
} // GetShortPath method

[DllImport("user32.dll")]
static extern bool SystemParametersInfo(int iAction, int iParam, out bool bActive, int iUpdate);
public static bool IsScreenReaderActive() {
int iAction = 70; // SPI_GETSCREENREADER constant;
int iParam = 0;
bool bActive;
int iUpdate = 0;
bool bReturn = SystemParametersInfo(iAction, iParam, out bActive, iUpdate);
return bReturn && bActive;
} // IsScreenReaderActive method

public static bool IsJAWSActive(){
string sClass = "JFWUI2";
string sTitle = "JAWS";
return (int) FindWindow(sClass, sTitle) != 0;
} // IsJAWSActive method

public static bool IsWinEyesActive(){
//string sClass = "AfxFrameOrView42";
//string sTitle = "Window-Eyes";
string sClass = "GWMExternalControl";
string sTitle = "External Control";
return (int) FindWindow(sClass, sTitle) != 0;
//int iClass = 0;
//return (int) FindWindow(iClass, sTitle) != 0;
} // IsWinEyesActive method

[DllImport("jfwapi.dll")]
public static extern int JFWRunFunction(string sText);

public static bool JAWSSay(string sText) {
//if (sText.Length < 2000) return JFWSay(sText);
if (JFWSay(sText)) return true;
//if (!JFWSay("")) return false;
if (!IsJAWSActive()) return false;

// Util.String2FileA(sText, App.TempFile);
return JFWRunFunction("SayTempFile") == 1;
} // JAWSSay method

[DllImport("jfwapi.dll")]
public static extern int JFWSayString(string sText, int iInterrupt);

public static bool JFWSay(string sText) {
try {
return JFWSayString(sText, 0) == 1;
}
catch {
return false;
}
} // JFWSay method

[DllImport("saapi32.dll")]
public static extern int SA_IsRunning();

public static bool IsSAActive() {
try {
return SA_IsRunning() == 1;
}
catch {
return false;
}
} // IsSAActive method

[DllImport("saapi32.dll")]
public static extern int SA_SayU(string sText);

public static bool SASay(string sText) {
try {
return SA_SayU(sText) == 1;
}
catch {
return false;
}
} // SASay method

[DllImport("user32.dll")]
public static extern int SendMessage(IntPtr h, int iMsg, int wParam, int lParam);

[DllImport("user32.dll")]
public static extern IntPtr GetForegroundWindow();

[DllImport("user32.dll")]
public static extern int SetForegroundWindow(IntPtr h);

[DllImport("user32.dll")]
public static extern IntPtr FindWindow(string sClass, string sTitle);

[DllImport("user32.dll")]
public static extern IntPtr FindWindow(int iClass, string sTitle);

[DllImport("user32.dll")]
public static extern IntPtr FindWindow(string sClass, int iTitle);

[DllImport("shell32.dll")]
public static extern int ShellExecute(int i1, string sVerb, string sFile, int i2, int i3, int i4);

public static int ShellExecute(string sVerb, string sFile) {
return ShellExecute(0, sVerb, sFile, 0, 0, 1);
} // ShellExecute method

[DllImport("shell32.dll")]
public static extern int ShellExecute(int i1, int i2, string sFile, int i3, int i4, int i5);

public static int ShellDefault(string sFile) {
return ShellExecute(0, 0, sFile, 0, 0, 1);
} // ShellDefault method

[DllImport("MSCorEE.dll", CharSet = CharSet.Auto)]
public static extern int GetCORSystemDirectory  (StringBuilder sbPath, int iSize, out int iLength);
public static string GetNetSdkDir() {
int iSize = 260;
StringBuilder sbPath = new StringBuilder(iSize);
int iLength;
GetCORSystemDirectory  (sbPath, iSize, out iLength);
return sbPath.ToString();
} // GetNetSdkDir method

public static string GetJFWDir() {
RegistryKey key = Registry.LocalMachine;
string sSubKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\";
string sName = "Path";
string sPath = GetRegString(key, (sSubKey + "jfw.exe"), sName);

if (sPath == "") {
string[] sVersions = {"12", "11", "10", "90", "81", "80", "8", "71", "70", "7", "62", "61", "60", "6"};
sName = "";
foreach (string sVersion in sVersions) {
sPath = GetRegString(key, (sSubKey + "jaws" + sVersion + ".exe"), sName);
if (sPath != "") {
sPath = Path.GetDirectoryName(sPath);
break;
}
}
}
//if (sPath !="" && !sPath.EndsWith(@"\")) sPath = String.Concat(sPath, @"\");
sPath = sPath.TrimEnd('\\');
return sPath;
} // GetJFWDir method

public static string GetWEDir() {
RegistryKey key = Registry.LocalMachine;
string sSubKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinEyes.exe";
string sName = "Path";
string sPath = GetRegString(key, sSubKey, sName);
if (sPath !="" && !sPath.EndsWith(@"\")) sPath = String.Concat(sPath, @"\");
return sPath;
} // GetWEDir method

public static string GetRegString(RegistryKey key, string sSubKey, string sName) {
RegistryKey subkey = null;
string sData = "";

try {
subkey = key.OpenSubKey(sSubKey);
sData = subkey.GetValue(sName).ToString();
}
catch {
}
finally {
if (subkey != null) subkey.Close();
}
return sData;
} // GetRegString method

[DllImport("urlmon.dll")]
public static extern int URLDownloadToFile(int i1, string sUrl, string sFile, int i2, int i3, int i4);

public static bool Url2File(string sUrl, string sFile) {
int iResult = URLDownloadToFile(0, sUrl, sFile, 0, 0, 0);
return iResult == 0;
} // Url2File method

[Serializable]
public struct ShellExecuteInfo {
public int Size;
public uint Mask;
public IntPtr hwnd;
public string Verb;
public string File;
public string Parameters;
public string Directory;
public uint Show;
public IntPtr InstApp;
public IntPtr IDList;
public string Class;
public IntPtr hkeyClass;
public uint HotKey;
public IntPtr Icon;
public IntPtr Monitor;
}

[DllImport("shell32.dll", SetLastError = true)]
extern public static bool ShellExecuteEx(ref ShellExecuteInfo lpExecInfo);

public const uint SW_NORMAL = 1;

public static void OpenWith(string file) {
ShellExecuteInfo sei = new ShellExecuteInfo();
sei.Size = Marshal.SizeOf(sei);
sei.Verb = "openas";
sei.File = file;
sei.Show = SW_NORMAL;
if (!ShellExecuteEx(ref sei))
throw new System.ComponentModel.Win32Exception();
} //OpenAs method

} // Win32 class

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
TextGRABSDKLib.TextGRABSDK tg = new TextGRABSDKLib.TextGRABSDK();
string sUser = "Jamal Mazrui";
string sKey = "CR26HM-LXNQK-ZRJD8-H9GZ3-RCHKC-6QL8W";
tg.SetLicense(sUser, sKey);
// int iHandle = 1771212;
// Win32.ForceWindow((IntPtr) iHandle);
// int iHandle = (int) Win32.GetActiveWindow();
int iHandle = (int) Win32.GetForegroundWindow();
if (iHandle == 0) {
MessageBox.Show("No active window!");
}
else {
string sText = "";
tg.CaptureFromHWND(iHandle, out sText);
MessageBox.Show(sText, "Results");
}

//             Application.Run(new Form1());
        }
    }
}